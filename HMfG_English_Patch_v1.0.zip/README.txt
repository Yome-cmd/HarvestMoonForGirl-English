Bokujou Monogatari: Harvest Moon for Girl - English Translation Patch
PlayStation (Japan), SLPS-03087 - Patcher version 1.0 (2026-10-10)
=====================================================================

WHAT YOU NEED
  Your own untouched dump of the Japanese disc as BIN/CUE (Redump format):
    Bokujou Monogatari - Harvest Moon for Girl (Japan).bin  (266,062,944 bytes)
    SHA-1: cfc39fc126717bf5f9cae25bf7e84f65fce1ce4a
  The game itself is NOT included.

HOW TO PATCH
  1. Drag the Japanese .bin file onto HMfG_English_Patcher.exe
     (or put the patcher in the same folder as the .bin and double-click it).
  2. Wait a few seconds. The patcher checks your file, applies the
     translation, checks the result, and creates in the same folder:
       Harvest Moon for Girl (English).bin
       Harvest Moon for Girl (English).cue
  3. Load the .cue in your emulator (DuckStation etc.), or burn the
     BIN/CUE to a CD-R for a real PlayStation.

  Result SHA-1: 3543192e9d17507ee1acd39f566438f05db96706

SAFETY
  - Works completely offline; no installation, no admin rights, no registry.
  - Never changes your original file; it only writes the two new files.
  - Refuses to run on the wrong file, and checks the result before saving.
  - Contains only the differences from the original disc, no game data.
  - Windows may show "Windows protected your PC" because the program is
    not code-signed. Click "More info" > "Run anyway".
  Patcher SHA-256: fe2f5c0cd071f1bf3d98af0b8a56efef56852074e8efd91ac1a92e87caeb7ada

NOTES
  - Circle and Cross are swapped to the Western layout (X = confirm).
  - Hold SELECT to fast-forward.
